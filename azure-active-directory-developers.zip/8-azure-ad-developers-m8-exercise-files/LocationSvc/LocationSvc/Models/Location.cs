﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LocationSvc.Models
{
    public class Location
    {
        public int Latitude { get; set; }
        public int Longitude { get; set; }
        public string UserName { get; set; }
    }
}